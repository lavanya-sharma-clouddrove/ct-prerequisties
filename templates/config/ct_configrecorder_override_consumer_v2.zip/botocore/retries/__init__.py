"""New retry v2 handlers.

This python obsoletes the botocore/retryhandler.py module and contains
new retry logic.

"""
