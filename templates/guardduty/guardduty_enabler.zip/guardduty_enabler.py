import boto3
import json
import os
import time
import logging
import urllib3
from botocore.exceptions import ClientError

# Initialize logger
LOGGER = logging.getLogger()
if 'LOG_LEVEL' in os.environ:
    LOGGER.setLevel(os.environ['LOG_LEVEL'])
    LOGGER.info("Log level set to %s", LOGGER.getEffectiveLevel())
else:
    LOGGER.setLevel(logging.ERROR)
logging.getLogger('boto3').setLevel(logging.CRITICAL)
logging.getLogger('botocore').setLevel(logging.CRITICAL)

# Initialize boto3 session
session = boto3.Session()

# Get excluded accounts from environment variables
excluded_accounts = os.environ.get('EXCLUDED_ACCOUNTS', '').split(',')
excluded_accounts = [account.strip() for account in excluded_accounts if account.strip()]

def send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
    response_url = event['ResponseURL']
    LOGGER.info(f"Response URL: {response_url}")
    
    responseBody = {
        'Status': responseStatus,
        'Reason': f'See the details in CloudWatch Log Stream: {context.log_stream_name}',
        'PhysicalResourceId': physicalResourceId or context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'NoEcho': noEcho,
        'Data': responseData
    }

    json_response_body = json.dumps(responseBody)
    LOGGER.info(f"Response body:\n{json_response_body}")

    headers = {
        'content-type': '',
        'content-length': str(len(json_response_body))
    }

    http = urllib3.PoolManager()
    try:
        response = http.request('PUT', response_url, body=json_response_body, headers=headers)
        LOGGER.info(f"Status code: {response.reason}")
    except Exception as e:
        LOGGER.error(f"send(..) failed executing requests.put(..): {str(e)}")

def get_enabled_regions(session, regions):
    enabled_regions = []
    for region in regions:
        sts_client = session.client('sts', region_name=region)
        try:
            sts_client.get_caller_identity()
            enabled_regions.append(region)
        except ClientError as e:
            if e.response['Error']['Code'] == "InvalidClientTokenId":
                LOGGER.debug(f"{region} region is disabled.")
            else:
                LOGGER.debug(f"Error {e.response['Error']} occurred testing region {region}")
    return enabled_regions

def get_account_list():
    aws_account_dict = dict()
    orgclient = session.client('organizations', region_name=session.region_name)
    accounts = orgclient.list_accounts()
    
    while 'NextToken' in accounts:
        more_accounts = orgclient.list_accounts(NextToken=accounts['NextToken'])
        for acct in accounts['Accounts']:
            more_accounts['Accounts'].append(acct)
        accounts = more_accounts

    for account in accounts['Accounts']:
        if account['Status'] == 'ACTIVE' and account['Id'] not in excluded_accounts:
            aws_account_dict[account['Id']] = account['Email']
        elif account['Id'] in excluded_accounts:
            LOGGER.info(f"Account {account['Id']} excluded from GuardDuty setup as per configuration")
    
    return aws_account_dict

def assume_role(aws_account_number, role_name):
    sts_client = boto3.client('sts')
    partition = sts_client.get_caller_identity()['Arn'].split(":")[1]
    
    response = sts_client.assume_role(
        RoleArn=f'arn:{partition}:iam::{aws_account_number}:role/{role_name}',
        RoleSessionName='EnableGuardDuty'
    )
    
    sts_session = boto3.Session(
        aws_access_key_id=response['Credentials']['AccessKeyId'],
        aws_secret_access_key=response['Credentials']['SecretAccessKey'],
        aws_session_token=response['Credentials']['SessionToken']
    )
    
    LOGGER.debug(f"Assumed session for {aws_account_number}.")
    return sts_session

def get_admin_members(admin_session, aws_region, detector_id):
    member_dict = {}
    gd_client = admin_session.client('guardduty', region_name=aws_region)
    
    paginator = gd_client.get_paginator('list_members')
    operation_parameters = {'DetectorId': detector_id, 'OnlyAssociated': 'false'}
    page_iterator = paginator.paginate(**operation_parameters)
    
    for page in page_iterator:
        for member in page.get('Members', []):
            member_dict[member['AccountId']] = member['RelationshipStatus']
    
    return member_dict

def list_detectors(client, aws_region):
    detector_dict = {}
    detectors = client.list_detectors()
    
    if detectors['DetectorIds']:
        for detector in detectors['DetectorIds']:
            detector_dict[aws_region] = detector
    else:
        detector_dict[aws_region] = ''
    
    return detector_dict

def log_status(action, account, admin, region, status):
    LOGGER.info(f"{action} account {account} from GuardDuty admin {admin} in region {region} because it is {status}")

def get_ct_regions(session):
    cf = session.client('cloudformation')
    stacks = cf.list_stack_instances(StackSetName='AWSControlTowerBP-BASELINE-CLOUDWATCH')
    region_set = set(stack['Region'] for stack in stacks['Summaries'])
    return list(region_set)

def list_members(client, detector_id):
    member_dict = {}
    response = client.list_members(DetectorId=detector_id, OnlyAssociated='false')
    
    for member in response['Members']:
        member_dict[member['AccountId']] = member['RelationshipStatus']
    
    return member_dict

def disable_guardduty(admin_session, guardduty_regions, admin_account):
    for aws_region in guardduty_regions:
        gd_client = admin_session.client('guardduty', region_name=aws_region)
        detector_dict = list_detectors(gd_client, aws_region)
        detector_id = detector_dict.get(aws_region)
        
        if detector_id:
            LOGGER.info(f"GuardDuty is active in {aws_region}")
            member_dict = list_members(gd_client, detector_id)
            
            if member_dict:
                LOGGER.info(f"There are members in {aws_region}.")
                gd_client.disassociate_members(DetectorId=detector_id, AccountIds=list(member_dict.keys()))
                gd_client.delete_members(DetectorId=detector_id, AccountIds=list(member_dict.keys()))
                LOGGER.info(f"Deleting members for {admin_account} in {aws_region}")
        else:
            LOGGER.info(f"No detector found for {admin_account} in {aws_region}")

def lambda_handler(event, context):
    LOGGER.debug('REQUEST RECEIVED:\n %s', event)
    LOGGER.debug('REQUEST RECEIVED:\n %s', context)
    
    admin_account = os.environ['ADMIN_ACCOUNT']
    admin_session = assume_role(admin_account, os.environ['ASSUME_ROLE'])
    
    if os.environ['REGION_FILTER'] == 'GuardDuty':
        guardduty_regions = get_enabled_regions(session, session.get_available_regions('guardduty', partition_name=os.environ['TOPIC'].split(":")[1]))
        LOGGER.debug(f"Enabling members in all available GuardDuty regions {guardduty_regions}")
    else:
        guardduty_regions = get_ct_regions(session)
        LOGGER.debug(f"Enabling members in all available ControlTower regions {guardduty_regions}")
    
    if 'RequestType' in event and event['RequestType'] in ["Delete", "Create", "Update"]:
        action = event['RequestType']
        if action == "Delete":
            disable_guardduty(admin_session, guardduty_regions, admin_account)
            LOGGER.info("Sending Custom Resource Response")
            send(event, context, "SUCCESS", {})
            raise SystemExit()
        else:
            LOGGER.info("Sending Custom Resource Response")
            send(event, context, "SUCCESS", {})
    
    aws_account_dict = {}
    if 'Records' in event:
        message = event['Records'][0]['Sns']['Message']
        LOGGER.debug(message)
        jsonmessage = json.loads(message)
        aws_account_dict[jsonmessage['AccountId']] = jsonmessage['Email']
    else:
        aws_account_dict = get_account_list()
        sns_client = session.client('sns', region_name=os.environ['AWS_REGION'])
        
        for accountid, email in aws_account_dict.items():
            LOGGER.debug(f"Sending job to configure account {accountid}")
            sns_client.publish(TopicArn=os.environ['TOPIC'], Message=json.dumps({"AccountId": accountid, "Email": email}))
        return True
    
    for aws_region in guardduty_regions:
        gd_client = admin_session.client('guardduty', region_name=aws_region)
        detector_dict = list_detectors(gd_client, aws_region)
        detector_id = detector_dict.get(aws_region)
        
        if detector_id:
            member_dict = get_admin_members(admin_session, aws_region, detector_id)
            for accountid, email in aws_account_dict.items():
                if accountid not in member_dict:
                    try:
                        gd_client.create_members(
                            AccountDetails=[{'AccountId': accountid, 'Email': email}],
                            DetectorId=detector_id
                        )
                        gd_client.invite_members(DetectorId=detector_id, AccountIds=[accountid])
                    except ClientError as e:
                        LOGGER.error(f"Error inviting account {accountid} to GuardDuty: {e}")
                else:
                    LOGGER.info(f"Account {accountid} is already a member in {aws_region}")

if __name__ == "__main__":
    lambda_handler({}, {})
